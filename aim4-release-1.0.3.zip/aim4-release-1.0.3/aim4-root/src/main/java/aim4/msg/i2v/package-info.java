/**
 * This package contains the implementation of the I2V messages in the
 * AIM protocol.
 */
package aim4.msg.i2v;
