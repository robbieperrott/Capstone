/**
 * This package contains the implementation of the UDP messages for the mixed
 * reality simulation.
 */
package aim4.msg.udp;
