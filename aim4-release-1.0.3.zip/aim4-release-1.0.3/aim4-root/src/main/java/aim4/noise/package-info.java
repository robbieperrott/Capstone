/**
 * This package contains the noise function for the sensors of the vehicle.
 */
package aim4.noise;
