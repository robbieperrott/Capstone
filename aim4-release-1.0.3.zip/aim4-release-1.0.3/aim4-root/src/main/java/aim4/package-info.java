/**
 * This is the root of the all packages of the AIM4 simulator.
 * The code of this simulator is based on the AIM3 simulator developed
 * by Kurt Dresner.
 */
package aim4;
