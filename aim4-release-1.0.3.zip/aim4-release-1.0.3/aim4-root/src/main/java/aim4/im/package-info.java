/**
 * This package contains the implementation of the intersection manager.
 */
package aim4.im;
