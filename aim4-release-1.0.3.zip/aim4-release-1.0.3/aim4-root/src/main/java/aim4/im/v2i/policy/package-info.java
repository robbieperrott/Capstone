/**
 * This package contains the implementation of various intersection control
 * policies for the V2I intersection manager.
 */
package aim4.im.v2i.policy;
