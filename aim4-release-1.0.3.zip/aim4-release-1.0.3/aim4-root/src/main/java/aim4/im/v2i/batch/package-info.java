/**
 * This package contains the implementation of the batch policy.
 */
package aim4.im.v2i.batch;
