/**
 * This package contains the implementation of the reservation manager for
 * the V2I intersection manager.
 */
package aim4.im.v2i.reservation;
