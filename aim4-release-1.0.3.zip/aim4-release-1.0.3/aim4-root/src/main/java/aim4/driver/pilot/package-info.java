/**
 * This package contains the implementation of the pilot,
 * one of the three agents in the driver agent.
 */
package aim4.driver.pilot;
