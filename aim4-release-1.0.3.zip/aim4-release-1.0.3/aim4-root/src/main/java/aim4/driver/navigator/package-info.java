/**
 * This package contains the implementation of the navigator,
 * one of the three agents in the driver agent.
 */
package aim4.driver.navigator;
