/**
 * This package contains the implementations of the simulation setup objects.
 */
package aim4.sim.setup;
