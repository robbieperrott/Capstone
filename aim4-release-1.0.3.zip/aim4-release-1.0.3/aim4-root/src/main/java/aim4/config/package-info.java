/**
 * This package contains the configuration settings for the AIM4 simulator.
 */
package aim4.config;
