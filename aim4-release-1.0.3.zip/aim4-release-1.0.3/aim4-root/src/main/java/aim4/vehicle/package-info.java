/**
 * This package contains the vehicle model in the simulator.
 */
package aim4.vehicle;
