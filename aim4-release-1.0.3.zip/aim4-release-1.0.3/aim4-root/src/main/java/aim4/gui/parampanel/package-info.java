/**
 * This package contains the panels for setting parameters in GUI.
 */
package aim4.gui.parampanel;
