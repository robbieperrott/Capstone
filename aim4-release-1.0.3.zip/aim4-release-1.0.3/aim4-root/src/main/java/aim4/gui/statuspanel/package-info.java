/**
 * This package contains the panels used by the GUI to show the status of the
 * simulation and to control the simulation.
 */
package aim4.gui.statuspanel;
