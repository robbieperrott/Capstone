/**
 * This package contains the Java Frames used by the GUI.
 */
package aim4.gui.frame;
