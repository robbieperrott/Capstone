/**
 * This package contains the Java components used by the GUI.
 */
package aim4.gui.component;
